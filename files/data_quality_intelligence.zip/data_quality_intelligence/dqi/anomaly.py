"""Simple statistical anomaly detection for numeric columns.

Two interchangeable methods are provided:
  - IQR (interquartile range): flags values outside Q1 - k*IQR, Q3 + k*IQR
  - Z-score: flags values more than `threshold` standard deviations from the mean

Both are intentionally simple, dependency-free (beyond pandas/numpy) methods
suitable as a first line of defense; swap in something fancier (Isolation
Forest, etc.) for production-grade anomaly detection.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Literal

import numpy as np
import pandas as pd


@dataclass
class AnomalyResult:
    """Outliers found in a single numeric column."""

    column: str
    method: str
    outlier_count: int
    outlier_pct: float
    lower_bound: float
    upper_bound: float
    sample_outliers: List[Any] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "column": self.column,
            "method": self.method,
            "outlier_count": self.outlier_count,
            "outlier_pct": round(self.outlier_pct, 4),
            "lower_bound": self.lower_bound,
            "upper_bound": self.upper_bound,
            "sample_outliers": self.sample_outliers,
        }


class AnomalyDetector:
    """Flags statistical outliers in numeric columns of a DataFrame.

    Example:
        detector = AnomalyDetector(df, method="iqr")
        results = detector.detect(columns=["age", "income"])
    """

    def __init__(
        self,
        df: pd.DataFrame,
        method: Literal["iqr", "zscore"] = "iqr",
        iqr_multiplier: float = 1.5,
        zscore_threshold: float = 3.0,
        sample_size: int = 5,
    ):
        self.df = df
        self.method = method
        self.iqr_multiplier = iqr_multiplier
        self.zscore_threshold = zscore_threshold
        self.sample_size = sample_size

    def detect(self, columns: List[str] = None) -> List[AnomalyResult]:
        cols = columns or [
            c for c in self.df.columns if pd.api.types.is_numeric_dtype(self.df[c])
        ]
        results = []
        for col in cols:
            if col not in self.df.columns or not pd.api.types.is_numeric_dtype(self.df[col]):
                continue
            result = self._detect_column(col)
            if result is not None:
                results.append(result)
        return results

    def _detect_column(self, col: str) -> AnomalyResult:
        series = self.df[col].dropna()
        if len(series) < 2:
            return AnomalyResult(
                column=col, method=self.method, outlier_count=0, outlier_pct=0.0,
                lower_bound=float("nan"), upper_bound=float("nan"),
            )

        if self.method == "zscore":
            mean, std = series.mean(), series.std()
            if std == 0:
                lower, upper = mean, mean
                mask = pd.Series(False, index=series.index)
            else:
                z = (series - mean) / std
                mask = z.abs() > self.zscore_threshold
                lower = mean - self.zscore_threshold * std
                upper = mean + self.zscore_threshold * std
        else:  # iqr
            q1, q3 = series.quantile(0.25), series.quantile(0.75)
            iqr = q3 - q1
            lower = q1 - self.iqr_multiplier * iqr
            upper = q3 + self.iqr_multiplier * iqr
            mask = (series < lower) | (series > upper)

        outliers = series[mask]
        return AnomalyResult(
            column=col,
            method=self.method,
            outlier_count=int(mask.sum()),
            outlier_pct=(mask.sum() / len(series)) if len(series) else 0.0,
            lower_bound=float(lower),
            upper_bound=float(upper),
            sample_outliers=outliers.head(self.sample_size).tolist(),
        )
