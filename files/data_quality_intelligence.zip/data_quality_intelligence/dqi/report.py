"""Turns profiling, rule, anomaly, and scoring results into a readable report."""

from __future__ import annotations

import json
from typing import List, Optional

from .anomaly import AnomalyResult
from .profiler import DatasetProfile
from .rules import RuleResult
from .scoring import QualityScore


class ReportGenerator:
    """Builds a human-readable (Markdown) or machine-readable (JSON) report."""

    def __init__(
        self,
        profile: DatasetProfile,
        rule_results: List[RuleResult],
        score: QualityScore,
        anomaly_results: Optional[List[AnomalyResult]] = None,
        dataset_name: str = "dataset",
    ):
        self.profile = profile
        self.rule_results = rule_results
        self.score = score
        self.anomaly_results = anomaly_results or []
        self.dataset_name = dataset_name

    def to_dict(self) -> dict:
        return {
            "dataset": self.dataset_name,
            "profile": self.profile.to_dict(),
            "rule_results": [r.to_dict() for r in self.rule_results],
            "anomaly_results": [a.to_dict() for a in self.anomaly_results],
            "score": self.score.to_dict(),
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)

    def to_markdown(self) -> str:
        lines = []
        lines.append(f"# Data Quality Report: {self.dataset_name}")
        lines.append("")
        lines.append(f"**Overall Score:** {self.score.overall:.2%} (Grade {self.score.grade})")
        lines.append(f"**Rows:** {self.profile.row_count}  ")
        lines.append(f"**Columns:** {self.profile.column_count}  ")
        lines.append(f"**Duplicate Rows:** {self.profile.duplicate_rows}")
        lines.append("")

        lines.append("## Column Scores")
        lines.append("")
        lines.append("| Column | Score | Completeness | Validity | Uniqueness | Rules Applied |")
        lines.append("|---|---|---|---|---|---|")
        for name, cs in self.score.columns.items():
            lines.append(
                f"| {name} | {cs.score:.2%} | {cs.completeness:.2%} | "
                f"{cs.validity:.2%} | {cs.uniqueness:.2%} | {cs.rules_applied} |"
            )
        lines.append("")

        failed_rules = [r for r in self.rule_results if not r.passed]
        lines.append("## Rule Violations")
        lines.append("")
        if not failed_rules:
            lines.append("No rule violations detected.")
        else:
            lines.append("| Rule | Column | Failed | Failed % | Sample Failures |")
            lines.append("|---|---|---|---|---|")
            for r in failed_rules:
                samples = ", ".join(str(s) for s in r.sample_failures)
                lines.append(f"| {r.rule_name} | {r.column} | {r.failed} | {r.failed_pct:.2%} | {samples} |")
        lines.append("")

        if self.anomaly_results:
            lines.append("## Anomalies (Statistical Outliers)")
            lines.append("")
            any_outliers = any(a.outlier_count > 0 for a in self.anomaly_results)
            if not any_outliers:
                lines.append("No statistical outliers detected.")
            else:
                lines.append("| Column | Method | Outliers | Outlier % | Bounds | Sample Outliers |")
                lines.append("|---|---|---|---|---|---|")
                for a in self.anomaly_results:
                    if a.outlier_count == 0:
                        continue
                    bounds = f"[{a.lower_bound:.2f}, {a.upper_bound:.2f}]"
                    samples = ", ".join(str(s) for s in a.sample_outliers)
                    lines.append(
                        f"| {a.column} | {a.method} | {a.outlier_count} | "
                        f"{a.outlier_pct:.2%} | {bounds} | {samples} |"
                    )
            lines.append("")

        return "\n".join(lines)

    def save(self, path: str, fmt: str = "markdown") -> None:
        content = self.to_markdown() if fmt == "markdown" else self.to_json()
        with open(path, "w") as f:
            f.write(content)
