"""
Data Quality Intelligence (DQI)
================================

A lightweight framework for profiling tabular data, validating it against
configurable rules, flagging statistical anomalies, and producing an overall
data quality score and report.

Typical usage:

    import pandas as pd
    from dqi import DataProfiler, RuleEngine, NotNullRule, RangeRule, QualityScorer

    df = pd.read_csv("customers.csv")

    profile = DataProfiler(df).profile()

    engine = RuleEngine([
        NotNullRule("customer_id"),
        RangeRule("age", min_value=0, max_value=120),
    ])
    rule_results = engine.run(df)

    score = QualityScorer().score(profile, rule_results)
    print(score.overall)
"""

from .profiler import DataProfiler, ColumnProfile
from .rules import (
    Rule,
    NotNullRule,
    UniqueRule,
    RangeRule,
    RegexRule,
    AllowedValuesRule,
    TypeRule,
    CustomRule,
    RuleEngine,
    RuleResult,
)
from .anomaly import AnomalyDetector, AnomalyResult
from .scoring import QualityScorer, QualityScore
from .report import ReportGenerator

__all__ = [
    "DataProfiler",
    "ColumnProfile",
    "Rule",
    "NotNullRule",
    "UniqueRule",
    "RangeRule",
    "RegexRule",
    "AllowedValuesRule",
    "TypeRule",
    "CustomRule",
    "RuleEngine",
    "RuleResult",
    "AnomalyDetector",
    "AnomalyResult",
    "QualityScorer",
    "QualityScore",
    "ReportGenerator",
]

__version__ = "0.1.0"
