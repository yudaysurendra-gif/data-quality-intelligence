"""Unit tests for the Data Quality Intelligence framework."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import pytest

from dqi import (
    DataProfiler,
    RuleEngine,
    NotNullRule,
    UniqueRule,
    RangeRule,
    RegexRule,
    AllowedValuesRule,
    CustomRule,
    AnomalyDetector,
    QualityScorer,
    ReportGenerator,
)


@pytest.fixture
def sample_df():
    return pd.DataFrame(
        {
            "id": [1, 2, 3, 3, 5],
            "age": [25, 40, None, 130, 30],
            "email": ["a@x.com", "b@x.com", "bad-email", "d@x.com", None],
            "country": ["US", "CA", "US", "ZZ", "US"],
        }
    )


def test_profiler_basic_stats(sample_df):
    profile = DataProfiler(sample_df).profile()
    assert profile.row_count == 5
    assert profile.column_count == 4
    assert profile.duplicate_rows == 0

    id_profile = profile.columns["id"]
    assert id_profile.missing == 0
    assert id_profile.unique == 4  # 1,2,3,5 (3 repeated)

    age_profile = profile.columns["age"]
    assert age_profile.missing == 1
    assert age_profile.is_numeric is True
    assert age_profile.max == 130


def test_not_null_rule(sample_df):
    result = NotNullRule("age").evaluate(sample_df)
    assert result.passed is False
    assert result.failed == 1


def test_unique_rule_flags_duplicates(sample_df):
    result = UniqueRule("id").evaluate(sample_df)
    assert result.passed is False
    assert result.failed == 1  # second "3"


def test_range_rule(sample_df):
    result = RangeRule("age", min_value=0, max_value=120).evaluate(sample_df)
    assert result.passed is False
    assert 130 in result.sample_failures


def test_regex_rule(sample_df):
    result = RegexRule("email", pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$").evaluate(sample_df)
    assert result.passed is False
    assert "bad-email" in result.sample_failures


def test_allowed_values_rule(sample_df):
    result = AllowedValuesRule("country", allowed=["US", "CA"]).evaluate(sample_df)
    assert result.passed is False
    assert "ZZ" in result.sample_failures


def test_custom_rule(sample_df):
    result = CustomRule("age", predicate=lambda v: v % 5 == 0, name="multiple_of_5").evaluate(sample_df)
    # 25, 40, 30 pass; 130 also passes (multiple of 5) -> only NaN skipped
    assert result.rule_name == "multiple_of_5"
    assert result.failed == 0


def test_rule_engine_runs_all_rules(sample_df):
    engine = RuleEngine([NotNullRule("age"), UniqueRule("id")])
    results = engine.run(sample_df)
    assert len(results) == 2
    assert {r.rule_name for r in results} == {"not_null", "unique"}


def test_missing_column_reports_gracefully(sample_df):
    result = NotNullRule("does_not_exist").evaluate(sample_df)
    assert result.passed is False
    assert "not found" in result.message


def test_anomaly_detector_iqr_flags_outlier():
    df = pd.DataFrame({"value": [10, 11, 12, 13, 14, 1000]})
    results = AnomalyDetector(df, method="iqr").detect(columns=["value"])
    assert len(results) == 1
    assert results[0].outlier_count == 1
    assert 1000 in results[0].sample_outliers


def test_anomaly_detector_zscore_method():
    df = pd.DataFrame({"value": [10, 11, 12, 13, 14, 1000]})
    results = AnomalyDetector(df, method="zscore", zscore_threshold=1.5).detect(columns=["value"])
    assert results[0].outlier_count >= 1


def test_scorer_produces_overall_and_grade(sample_df):
    profile = DataProfiler(sample_df).profile()
    engine = RuleEngine([NotNullRule("age"), UniqueRule("id")])
    rule_results = engine.run(sample_df)

    score = QualityScorer().score(profile, rule_results)
    assert 0.0 <= score.overall <= 1.0
    assert score.grade in {"A", "B", "C", "D", "F"}
    assert set(score.columns.keys()) == set(sample_df.columns)


def test_scorer_perfect_data_scores_high():
    df = pd.DataFrame({"id": [1, 2, 3], "val": [10, 20, 30]})
    profile = DataProfiler(df).profile()
    engine = RuleEngine([NotNullRule("id"), UniqueRule("id"), NotNullRule("val")])
    rule_results = engine.run(df)
    score = QualityScorer().score(profile, rule_results)
    assert score.overall == 1.0
    assert score.grade == "A"


def test_report_generator_outputs_markdown_and_json(sample_df):
    profile = DataProfiler(sample_df).profile()
    engine = RuleEngine([NotNullRule("age")])
    rule_results = engine.run(sample_df)
    score = QualityScorer().score(profile, rule_results)

    report = ReportGenerator(profile, rule_results, score, dataset_name="test")
    md = report.to_markdown()
    js = report.to_json()

    assert "Data Quality Report: test" in md
    assert '"dataset": "test"' in js
